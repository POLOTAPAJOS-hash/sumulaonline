import { useStore } from '../store';
import { Trophy, Users, CalendarDays, Activity, Layers } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useMemo } from 'react';

export default function Dashboard() {
  const { teams, matches } = useStore();

  const stats = [
    { name: 'Equipes Inscritas', value: teams.length, icon: Users, color: 'bg-blue-500' },
    { name: 'Partidas Agendadas', value: matches.filter(m => m.status === 'scheduled').length, icon: CalendarDays, color: 'bg-amber-500' },
    { name: 'Partidas Finalizadas', value: matches.filter(m => m.status === 'finished').length, icon: Trophy, color: 'bg-emerald-500' },
    { name: 'Gols Marcados', value: matches.reduce((acc, m) => acc + m.homeScore + m.awayScore, 0), icon: Activity, color: 'bg-purple-500' },
  ];

  const recentMatches = matches
    .filter(m => m.status === 'finished')
    .slice(-5)
    .reverse();

  const groupsByCategory = useMemo(() => {
    const data: Record<string, Record<string, typeof teams>> = {};
    teams.forEach(team => {
      if (team.group) {
        if (!data[team.category]) {
          data[team.category] = {};
        }
        if (!data[team.category][team.group]) {
          data[team.category][team.group] = [];
        }
        data[team.category][team.group].push(team);
      }
    });
    return data;
  }, [teams]);

  const hasGroups = Object.keys(groupsByCategory).length > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Visão Geral</h1>
        <p className="text-gray-500 mt-1">Resumo do campeonato Polo Tapajós de Futsal.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-center gap-4">
            <div className={`p-3 rounded-lg text-white ${stat.color}`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">{stat.name}</p>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">Últimos Resultados</h2>
            <Link to="/matches" className="text-sm text-emerald-600 hover:text-emerald-700 font-medium">
              Ver todas
            </Link>
          </div>
          
          {recentMatches.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Nenhuma partida finalizada ainda.
            </div>
          ) : (
            <div className="space-y-4">
              {recentMatches.map((match) => {
                const homeTeam = teams.find(t => t.id === match.homeTeamId);
                const awayTeam = teams.find(t => t.id === match.awayTeamId);
                
                return (
                  <div key={match.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1 text-right font-medium truncate pr-4">
                      {homeTeam?.name || 'Time Excluído'}
                    </div>
                    <div className="px-4 py-1 bg-gray-900 text-white font-bold rounded text-sm">
                      {match.homeScore} - {match.awayScore}
                    </div>
                    <div className="flex-1 text-left font-medium truncate pl-4">
                      {awayTeam?.name || 'Time Excluído'}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Ações Rápidas</h2>
          <div className="grid grid-cols-2 gap-4">
            <Link to="/teams" className="p-4 border border-gray-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition-colors text-center">
              <Users className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <span className="font-medium text-gray-900">Gerenciar Equipes</span>
            </Link>
            <Link to="/matches" className="p-4 border border-gray-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition-colors text-center">
              <CalendarDays className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <span className="font-medium text-gray-900">Tabela de Jogos</span>
            </Link>
            <Link to="/standings" className="p-4 border border-gray-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition-colors text-center">
              <Trophy className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <span className="font-medium text-gray-900">Classificação</span>
            </Link>
          </div>
        </div>
      </div>

      {hasGroups && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-2 mb-6">
            <Layers className="w-6 h-6 text-emerald-600" />
            <h2 className="text-lg font-bold text-gray-900">Grupos por Categoria</h2>
          </div>
          
          <div className="space-y-8">
            {Object.entries(groupsByCategory).map(([category, groups]) => (
              <div key={category}>
                <h3 className="flex items-center gap-2 text-md font-bold text-gray-800 mb-4 pb-2 border-b border-gray-100">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  {category}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {Object.entries(groups).sort(([a], [b]) => a.localeCompare(b)).map(([groupName, groupTeams]) => (
                    <div key={groupName} className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                      <h4 className="font-bold text-emerald-700 bg-emerald-50 rounded px-2 py-1 mb-3 text-center text-sm border border-emerald-100">
                        Grupo {groupName}
                      </h4>
                      <ul className="space-y-2">
                        {groupTeams.map(team => (
                          <li key={team.id} className="flex items-center gap-2 text-sm bg-white p-2 rounded shadow-sm border border-gray-50">
                            {team.logoUrl ? (
                              <img src={team.logoUrl} alt={team.name} className="w-5 h-5 rounded-full object-cover border border-gray-200" />
                            ) : (
                              <div className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center border border-gray-200">
                                <Users className="w-3 h-3 text-gray-400" />
                              </div>
                            )}
                            <span className="font-medium text-gray-800 truncate">{team.name}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
