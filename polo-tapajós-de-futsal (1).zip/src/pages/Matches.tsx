import { useMemo, useState } from 'react';
import { useStore, Match, MatchEvent, Category } from '../store';
import { format } from 'date-fns';
import { CalendarDays, Play, CheckCircle, Edit2, Trash2, Users, ClipboardList, Plus, X, Filter, Layers } from 'lucide-react';

const CATEGORIES: Category[] = ['Sub 07', 'Sub 08', 'Sub 09', 'Sub 10', 'Sub 11', 'Sub 12', 'Sub 13', 'Sub 14', 'Sub 15', 'Sub 16', 'Sub 17', 'Sub 18', 'Sub 19', 'Sub 20'];

export default function Matches() {
  const { teams, matches, generateRoundRobin, updateMatchStatus, updateMatchScore, addMatchEvent, removeMatchEvent, removeMatch, addMatch } = useStore();
  const [editingMatch, setEditingMatch] = useState<string | null>(null);
  const [matchToDelete, setMatchToDelete] = useState<string | null>(null);
  const [tempScore, setTempScore] = useState({ home: 0, away: 0 });
  const [showGenerateConfirm, setShowGenerateConfirm] = useState(false);
  const [roundRobinType, setRoundRobinType] = useState<'single' | 'double'>('single');
  const [selectedMatchForEvents, setSelectedMatchForEvents] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'Todas'>('Todas');
  const [isActionsMenuOpen, setIsActionsMenuOpen] = useState(false);
  const [showAddMatchModal, setShowAddMatchModal] = useState(false);
  const [newMatchData, setNewMatchData] = useState({
    homeTeamId: '',
    awayTeamId: '',
    date: new Date().toISOString().split('T')[0]
  });
  const [newEvent, setNewEvent] = useState<{ teamId: string; playerId: string; type: 'goal' | 'yellow_card' | 'red_card' }>({
    teamId: '',
    playerId: '',
    type: 'goal'
  });

  const [suspensionAlert, setSuspensionAlert] = useState<{ playerName: string, reason: string } | null>(null);

  const startEditing = (match: Match) => {
    setEditingMatch(match.id);
    setTempScore({ home: match.homeScore, away: match.awayScore });
  };

  const saveScore = (matchId: string) => {
    updateMatchScore(matchId, tempScore.home, tempScore.away);
    setEditingMatch(null);
  };

  const handleAddEvent = (matchId: string) => {
    if (!newEvent.teamId || !newEvent.playerId) return;
    
    // Add the event
    addMatchEvent(matchId, {
      teamId: newEvent.teamId,
      playerId: newEvent.playerId,
      type: newEvent.type
    });

    // Check for suspensions
    if (newEvent.type === 'yellow_card' || newEvent.type === 'red_card') {
      const allEventsForPlayer = matches.flatMap(m => m.events).filter(e => e.playerId === newEvent.playerId);
      const manualPlayer = teams.find(t => t.id === newEvent.teamId)?.players.find(p => p.id === newEvent.playerId);
      
      let totalYellows = manualPlayer?.yellowCards || 0;
      let totalReds = manualPlayer?.redCards || 0;
      
      // Add the current event to the counts since addMatchEvent might not have processed fully in this immediate line
      if (newEvent.type === 'yellow_card') totalYellows++;
      if (newEvent.type === 'red_card') totalReds++;
      
      // Note: we add past events if we solely rely on events, but manual player state likely tracks it.
      // Wait, if manual player state tracks it manually vs events tracking it. We just count events.
      const eventYellows = allEventsForPlayer.filter(e => e.type === 'yellow_card').length + (newEvent.type === 'yellow_card' ? 1 : 0);
      const eventReds = allEventsForPlayer.filter(e => e.type === 'red_card').length + (newEvent.type === 'red_card' ? 1 : 0);
      
      if (eventReds >= 1 || totalReds >= 1) {
        setSuspensionAlert({ playerName: manualPlayer?.name || 'Atleta', reason: 'Cartão Vermelho direto' });
      } else if (eventYellows >= 3 || totalYellows >= 3) {
        setSuspensionAlert({ playerName: manualPlayer?.name || 'Atleta', reason: 'Acúmulo de 3 cartões amarelos' });
      }
    }

    setNewEvent({ ...newEvent, playerId: '' });
  };

  const openEventsModal = (match: Match) => {
    setSelectedMatchForEvents(match.id);
    setNewEvent({ teamId: match.homeTeamId, playerId: '', type: 'goal' });
  };

  const selectedMatch = matches.find(m => m.id === selectedMatchForEvents);
  const selectedMatchHomeTeam = teams.find(t => t.id === selectedMatch?.homeTeamId);
  const selectedMatchAwayTeam = teams.find(t => t.id === selectedMatch?.awayTeamId);
  const selectedEventTeam = teams.find(t => t.id === newEvent.teamId);

  const handleDeleteMatch = (matchId: string) => {
    setMatchToDelete(matchId);
  };

  const confirmDeleteMatch = () => {
    if (matchToDelete) {
      removeMatch(matchToDelete);
      setMatchToDelete(null);
    }
  };

  const handleManualAddMatch = () => {
    if (!newMatchData.homeTeamId || !newMatchData.awayTeamId) {
      alert('Selecione ambas as equipes.');
      return;
    }
    if (newMatchData.homeTeamId === newMatchData.awayTeamId) {
      alert('Selecione equipes diferentes.');
      return;
    }
    
    addMatch({
      homeTeamId: newMatchData.homeTeamId,
      awayTeamId: newMatchData.awayTeamId,
      date: new Date(newMatchData.date).toISOString()
    });
    
    setShowAddMatchModal(false);
    setNewMatchData({
      homeTeamId: '',
      awayTeamId: '',
      date: new Date().toISOString().split('T')[0]
    });
  };

  const groupedMatches = useMemo(() => {
    const grouped: Record<string, Record<string, Match[]>> = {};

    matches.forEach(match => {
      const homeTeam = teams.find(t => t.id === match.homeTeamId);
      if (!homeTeam) return;

      if (selectedCategory !== 'Todas' && homeTeam.category !== selectedCategory) return;

      const cat = homeTeam.category;
      const group = homeTeam.group || 'Fase Única / Sem Grupo';

      if (!grouped[cat]) grouped[cat] = {};
      if (!grouped[cat][group]) grouped[cat][group] = [];

      grouped[cat][group].push(match);
    });

    return grouped;
  }, [matches, teams, selectedCategory]);

  return (
    <div className="space-y-6">
      {/* Match Events Modal */}
      {selectedMatchForEvents && selectedMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50 p-4">
          <div className="bg-white rounded-xl shadow-lg max-w-2xl w-full p-6 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-emerald-600" />
                Súmula da Partida
              </h3>
              <button onClick={() => setSelectedMatchForEvents(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center justify-center gap-4 mb-6 bg-gray-50 p-4 rounded-lg">
              <div className="text-right font-bold text-gray-900 truncate flex-1">
                {selectedMatchHomeTeam?.name}
              </div>
              <div className="text-2xl font-black tracking-widest text-gray-900 px-4">
                {selectedMatch.homeScore} <span className="text-gray-400 font-normal text-lg mx-1">X</span> {selectedMatch.awayScore}
              </div>
              <div className="text-left font-bold text-gray-900 truncate flex-1">
                {selectedMatchAwayTeam?.name}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Equipe</label>
                <select
                  value={newEvent.teamId}
                  onChange={(e) => setNewEvent({ ...newEvent, teamId: e.target.value, playerId: '' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                >
                  <option value={selectedMatch.homeTeamId}>{selectedMatchHomeTeam?.name}</option>
                  <option value={selectedMatch.awayTeamId}>{selectedMatchAwayTeam?.name}</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Atleta</label>
                <select
                  value={newEvent.playerId}
                  onChange={(e) => setNewEvent({ ...newEvent, playerId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                >
                  <option value="">Selecione...</option>
                  {selectedEventTeam?.players.map(p => (
                    <option key={p.id} value={p.id}>{p.number} - {p.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Evento</label>
                <div className="flex gap-2">
                  <select
                    value={newEvent.type}
                    onChange={(e) => setNewEvent({ ...newEvent, type: e.target.value as any })}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                  >
                    <option value="goal">Gol ⚽</option>
                    <option value="yellow_card">Cartão Amarelo 🟨</option>
                    <option value="red_card">Cartão Vermelho 🟥</option>
                  </select>
                  <button
                    onClick={() => handleAddEvent(selectedMatch.id)}
                    disabled={!newEvent.playerId}
                    className="p-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto border border-gray-200 rounded-lg">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b border-gray-200 sticky top-0">
                  <tr>
                    <th className="px-4 py-3 font-medium">Equipe</th>
                    <th className="px-4 py-3 font-medium">Atleta</th>
                    <th className="px-4 py-3 font-medium">Evento</th>
                    <th className="px-4 py-3 font-medium text-right">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedMatch.events.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-4 py-8 text-center text-gray-500">
                        Nenhum evento registrado nesta partida.
                      </td>
                    </tr>
                  ) : (
                    selectedMatch.events.map((event) => {
                      const team = teams.find(t => t.id === event.teamId);
                      const player = team?.players.find(p => p.id === event.playerId);
                      return (
                        <tr key={event.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                          <td className="px-4 py-3 font-medium text-gray-900">{team?.name}</td>
                          <td className="px-4 py-3">{player?.number} - {player?.name}</td>
                          <td className="px-4 py-3">
                            {event.type === 'goal' && <span className="flex items-center gap-1 font-medium text-emerald-600">⚽ Gol</span>}
                            {event.type === 'yellow_card' && <span className="flex items-center gap-1 font-medium text-yellow-600"><span className="inline-block w-3 h-4 bg-yellow-400 rounded-sm"></span> Cartão Amarelo</span>}
                            {event.type === 'red_card' && <span className="flex items-center gap-1 font-medium text-red-600"><span className="inline-block w-3 h-4 bg-red-500 rounded-sm"></span> Cartão Vermelho</span>}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              onClick={() => removeMatchEvent(selectedMatch.id, event.id)}
                              className="text-gray-400 hover:text-red-600 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Suspension Alert Modal */}
      {suspensionAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50 p-4">
          <div className="bg-white rounded-xl shadow-lg max-w-sm w-full p-6 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="w-8 h-10 bg-red-600 rounded-sm inline-block"></span>
            </div>
            <h3 className="text-xl font-black text-gray-900 mb-2">Atenção!</h3>
            <p className="text-gray-700 font-medium mb-1">O atleta <span className="font-bold">{suspensionAlert.playerName}</span> deve ser suspenso.</p>
            <p className="text-sm text-gray-500 mb-6">Motivo: {suspensionAlert.reason}. Lembre-se de registrar a suspensão e sua duração para evitar escalações irregulares.</p>
            <button 
              onClick={() => setSuspensionAlert(null)} 
              className="w-full px-4 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 transition-colors"
            >
              Ciente
            </button>
          </div>
        </div>
      )}

      {/* Delete Match Modal */}
      {matchToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50 p-4">
          <div className="bg-white rounded-xl shadow-lg max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Excluir Partida</h3>
            <p className="text-gray-500 mb-6 text-sm">Tem certeza que deseja excluir esta partida? Esta ação não pode ser desfeita.</p>
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setMatchToDelete(null)} 
                className="px-4 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={confirmDeleteMatch} 
                className="px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Match Modal */}
      {showAddMatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50 p-4">
          <div className="bg-white rounded-xl shadow-lg max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5 text-emerald-600" />
              Nova Partida Manual
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Data e Hora</label>
                <input
                  type="datetime-local"
                  value={newMatchData.date}
                  onChange={(e) => setNewMatchData({ ...newMatchData, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Time Mandante</label>
                <select
                  value={newMatchData.homeTeamId}
                  onChange={(e) => setNewMatchData({ ...newMatchData, homeTeamId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                >
                  <option value="">Selecione...</option>
                  {teams.map(t => <option key={t.id} value={t.id}>{t.category} - {t.name}</option>)}
                </select>
              </div>

              <div className="flex justify-center my-2">
                <span className="text-sm font-bold text-gray-400">X</span>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Time Visitante</label>
                <select
                  value={newMatchData.awayTeamId}
                  onChange={(e) => setNewMatchData({ ...newMatchData, awayTeamId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                >
                  <option value="">Selecione...</option>
                  {teams.map(t => <option key={t.id} value={t.id}>{t.category} - {t.name}</option>)}
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button 
                onClick={() => setShowAddMatchModal(false)} 
                className="px-4 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={handleManualAddMatch} 
                className="px-4 py-2 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors"
              >
                Adicionar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Partidas</h1>
          <p className="text-gray-500 mt-1">Gerencie a tabela de jogos e resultados.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as Category | 'Todas')}
              className="text-sm border-none bg-transparent focus:ring-0 text-gray-700 font-medium cursor-pointer outline-none"
            >
              <option value="Todas">Todas as Categorias</option>
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          <div className="relative">
            <button
              onClick={() => setIsActionsMenuOpen(!isActionsMenuOpen)}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors whitespace-nowrap"
            >
              <CalendarDays className="w-5 h-5" />
              Ações da Tabela
            </button>
            
            {isActionsMenuOpen && (
              <>
                <div 
                  className="fixed inset-0 z-10" 
                  onClick={() => setIsActionsMenuOpen(false)}
                ></div>
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden z-20">
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setShowAddMatchModal(true);
                        setIsActionsMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors text-left font-medium"
                    >
                      <Plus className="w-4 h-4" />
                      Adicionar Partida Manual
                    </button>
                    <button
                      onClick={() => {
                        generateRoundRobin(false);
                        setIsActionsMenuOpen(false);
                      }}
                      disabled={teams.length < 2}
                      className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors text-left font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Play className="w-4 h-4" />
                      Gerar Jogos de Ida
                    </button>
                    <button
                      onClick={() => {
                        generateRoundRobin(true);
                        setIsActionsMenuOpen(false);
                      }}
                      disabled={teams.length < 2}
                      className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors text-left font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Play className="w-4 h-4" />
                      Gerar Jogos de Ida e Volta
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {Object.keys(groupedMatches).length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="text-center py-12 text-gray-500">
            <CalendarDays className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p>Nenhuma partida agendada para a categoria selecionada.</p>
            <p className="text-sm mt-1">Adicione equipes e gere a tabela para começar.</p>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          {Object.entries(groupedMatches).sort(([a], [b]) => a.localeCompare(b)).map(([category, groups]) => (
            <div key={category} className="space-y-4">
              <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b border-gray-200 pb-2">
                <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                Categoria {category}
              </h2>

              <div className="space-y-6 pt-2">
                {Object.entries(groups).sort(([a], [b]) => a.localeCompare(b)).map(([groupName, groupMatches]) => (
                  <div key={groupName} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <div className="bg-gray-50/80 px-6 py-3 border-b border-gray-100 flex items-center gap-2">
                      <Layers className="w-4 h-4 text-emerald-600" />
                      <h3 className="font-bold text-gray-700">
                        {groupName === 'Fase Única / Sem Grupo' ? groupName : `Grupo ${groupName}`}
                      </h3>
                    </div>
                    <div className="divide-y divide-gray-100">
                      {groupMatches.map((match) => {
                        const homeTeam = teams.find((t) => t.id === match.homeTeamId);
                        const awayTeam = teams.find((t) => t.id === match.awayTeamId);
                        const isEditing = editingMatch === match.id;

                        return (
                          <div key={match.id} className="p-4 sm:p-6 flex flex-col items-center gap-4 hover:bg-gray-50 transition-colors">
                            {/* Header: Date / Time */}
                            <div className="w-full flex items-center justify-center sm:justify-start gap-2 pb-3 border-b border-gray-100 sm:border-0 sm:pb-0 text-sm text-gray-500">
                              <CalendarDays className="w-4 h-4" />
                              {format(new Date(match.date), 'dd/MM/yyyy HH:mm')}
                            </div>

                            {/* Center: Teams & Score */}
                            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-6 w-full max-w-2xl">
                              {/* Home Team */}
                              <div className="flex-1 flex flex-col-reverse sm:flex-row items-center sm:justify-end gap-1 sm:gap-3 w-full">
                                <div className="text-center sm:text-right font-bold text-gray-900 truncate text-sm sm:text-lg w-full">
                                  {homeTeam?.name || 'Time Excluído'}
                                </div>
                                {homeTeam?.logoUrl ? (
                                  <img src={homeTeam.logoUrl} alt={homeTeam?.name} className="w-12 h-12 sm:w-10 sm:h-10 rounded-full object-contain p-0.5 bg-white border border-gray-200 shadow-sm shrink-0" />
                                ) : (
                                  <div className="w-12 h-12 sm:w-10 sm:h-10 rounded-full bg-gray-100 flex items-center justify-center border border-gray-200 shadow-sm shrink-0">
                                    <Users className="w-5 h-5 text-gray-400" />
                                  </div>
                                )}
                              </div>

                              {/* Score */}
                              <div className="flex items-center gap-2 px-3 py-2 sm:px-4 sm:py-2 bg-gray-100 rounded-lg shrink-0 w-auto">
                                {isEditing ? (
                                  <>
                                    <input
                                      type="number"
                                      min="0"
                                      className="w-10 sm:w-12 text-center font-bold text-lg sm:text-xl bg-white border border-gray-300 rounded"
                                      value={tempScore.home}
                                      onChange={(e) => setTempScore({ ...tempScore, home: parseInt(e.target.value) || 0 })}
                                    />
                                    <span className="text-gray-400 font-bold mx-1">X</span>
                                    <input
                                      type="number"
                                      min="0"
                                      className="w-10 sm:w-12 text-center font-bold text-lg sm:text-xl bg-white border border-gray-300 rounded"
                                      value={tempScore.away}
                                      onChange={(e) => setTempScore({ ...tempScore, away: parseInt(e.target.value) || 0 })}
                                    />
                                  </>
                                ) : (
                                  <div className="text-xl sm:text-2xl font-black tracking-widest text-gray-900 px-2">
                                    {match.homeScore} <span className="text-gray-400 font-normal text-base sm:text-lg mx-1 sm:mx-2">X</span> {match.awayScore}
                                  </div>
                                )}
                              </div>

                              {/* Away Team */}
                              <div className="flex-1 flex flex-col sm:flex-row items-center sm:justify-start gap-1 sm:gap-3 w-full">
                                {awayTeam?.logoUrl ? (
                                  <img src={awayTeam.logoUrl} alt={awayTeam?.name} className="w-12 h-12 sm:w-10 sm:h-10 rounded-full object-contain p-0.5 bg-white border border-gray-200 shadow-sm shrink-0" />
                                ) : (
                                  <div className="w-12 h-12 sm:w-10 sm:h-10 rounded-full bg-gray-100 flex items-center justify-center border border-gray-200 shadow-sm shrink-0">
                                    <Users className="w-5 h-5 text-gray-400" />
                                  </div>
                                )}
                                <div className="text-center sm:text-left font-bold text-gray-900 truncate text-sm sm:text-lg w-full">
                                  {awayTeam?.name || 'Time Excluído'}
                                </div>
                              </div>
                            </div>

                            {/* Footer: Actions */}
                            <div className="w-full flex flex-wrap items-center justify-center sm:justify-end gap-2 pt-3 border-t border-gray-100 sm:border-0 sm:pt-0 shrink-0">
                              {match.status === 'scheduled' && (
                                <button
                                  onClick={() => updateMatchStatus(match.id, 'in_progress')}
                                  className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-blue-700 bg-blue-50 rounded hover:bg-blue-100"
                                >
                                  <Play className="w-4 h-4" /> Iniciar
                                </button>
                              )}
                              
                              {(match.status === 'in_progress' || match.status === 'finished') && (
                                <>
                                  {isEditing ? (
                                    <button
                                      onClick={() => saveScore(match.id)}
                                      className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-white bg-emerald-600 rounded hover:bg-emerald-700"
                                    >
                                      Salvar
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => startEditing(match)}
                                      className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-700 bg-gray-100 rounded hover:bg-gray-200"
                                    >
                                      <Edit2 className="w-4 h-4" /> Placar
                                    </button>
                                  )}

                                  <select
                                    value={match.status}
                                    onChange={(e) => updateMatchStatus(match.id, e.target.value as 'in_progress' | 'finished')}
                                    className={`px-3 py-1.5 text-sm font-medium rounded outline-none border border-transparent focus:border-emerald-500 cursor-pointer ${
                                      match.status === 'in_progress' ? 'bg-blue-50 text-blue-700' : 'bg-emerald-50 text-emerald-700'
                                    }`}
                                  >
                                    <option value="in_progress">Em Andamento</option>
                                    <option value="finished">Finalizado</option>
                                  </select>

                                  <button
                                    onClick={() => openEventsModal(match)}
                                    className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-purple-700 bg-purple-50 rounded hover:bg-purple-100"
                                  >
                                    <ClipboardList className="w-4 h-4" /> Súmula
                                  </button>
                                </>
                              )}

                              <button
                                onClick={() => handleDeleteMatch(match.id)}
                                className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-red-700 bg-red-50 rounded hover:bg-red-100 ml-auto sm:ml-0"
                                title="Excluir Partida"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
