import React, { useState } from 'react';
import { useStore } from '../store';
import { Save } from 'lucide-react';

export default function Settings() {
  const { name, setName } = useStore();
  const [tempName, setTempName] = useState(name);
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setName(tempName);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Configurações</h1>
        <p className="text-gray-500 mt-1">Ajuste as preferências do seu campeonato.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <form onSubmit={handleSave} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
              Nome do Campeonato
            </label>
            <input
              type="text"
              id="name"
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
              placeholder="Ex: Copa Verão 2024"
            />
          </div>

          <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors"
            >
              <Save className="w-5 h-5" />
              Salvar Alterações
            </button>
            
            {saved && (
              <span className="text-emerald-600 font-medium text-sm">
                Salvo com sucesso!
              </span>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
