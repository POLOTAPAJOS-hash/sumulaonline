import { useStore, Category } from '../store';
import { Trophy, Users, Filter, Layers, ChevronDown, ChevronRight } from 'lucide-react';
import { useMemo, useState } from 'react';

const CATEGORIES: Category[] = ['Sub 07', 'Sub 08', 'Sub 09', 'Sub 10', 'Sub 11', 'Sub 12', 'Sub 13', 'Sub 14', 'Sub 15', 'Sub 16', 'Sub 17', 'Sub 18', 'Sub 19', 'Sub 20'];

interface TeamStats {
  id: string;
  name: string;
  category: Category;
  group?: string;
  logoUrl?: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
}

export default function Standings() {
  const { teams, matches } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<Category | 'Todas'>('Todas');
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

  const toggleGroup = (groupKey: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [groupKey]: !prev[groupKey]
    }));
  };

  const standingsData = useMemo(() => {
    const statsMap = new Map<string, TeamStats>();

    // Initialize stats
    teams.forEach((team) => {
      statsMap.set(team.id, {
        id: team.id,
        name: team.name,
        category: team.category,
        group: team.group,
        logoUrl: team.logoUrl,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        goalsFor: 0,
        goalsAgainst: 0,
        goalDifference: 0,
        points: 0,
      });
    });

    // Calculate from finished matches
    matches
      .filter((m) => m.status === 'finished')
      .forEach((match) => {
        const homeStats = statsMap.get(match.homeTeamId);
        const awayStats = statsMap.get(match.awayTeamId);

        if (homeStats && awayStats) {
          homeStats.played++;
          awayStats.played++;

          homeStats.goalsFor += match.homeScore;
          homeStats.goalsAgainst += match.awayScore;
          awayStats.goalsFor += match.awayScore;
          awayStats.goalsAgainst += match.homeScore;

          if (match.homeScore > match.awayScore) {
            homeStats.won++;
            homeStats.points += 3;
            awayStats.lost++;
          } else if (match.homeScore < match.awayScore) {
            awayStats.won++;
            awayStats.points += 3;
            homeStats.lost++;
          } else {
            homeStats.drawn++;
            awayStats.drawn++;
            homeStats.points += 1;
            awayStats.points += 1;
          }
        }
      });

    // Calculate goal difference and sort
    const allStandings = Array.from(statsMap.values()).map((stat) => ({
      ...stat,
      goalDifference: stat.goalsFor - stat.goalsAgainst,
    })).sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.won !== a.won) return b.won - a.won;
      if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference;
      return b.goalsFor - a.goalsFor;
    });

    // Group by Category -> Group
    const grouped: Record<string, Record<string, TeamStats[]>> = {};

    allStandings.forEach(stat => {
      if (selectedCategory !== 'Todas' && stat.category !== selectedCategory) return;

      if (!grouped[stat.category]) {
        grouped[stat.category] = {};
      }
      
      const groupKey = stat.group || 'Fase Única / Sem Grupo';
      if (!grouped[stat.category][groupKey]) {
        grouped[stat.category][groupKey] = [];
      }
      
      grouped[stat.category][groupKey].push(stat);
    });

    return grouped;
  }, [teams, matches, selectedCategory]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Classificação</h1>
          <p className="text-gray-500 mt-1">Tabela de pontos separada por categorias e grupos.</p>
        </div>
        <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value as Category | 'Todas')}
            className="text-sm border-none bg-transparent focus:ring-0 text-gray-700 font-medium cursor-pointer outline-none"
          >
            <option value="Todas">Todas as Categorias</option>
            {CATEGORIES.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {Object.keys(standingsData).length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center text-gray-500">
          <Trophy className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p>Nenhuma equipe cadastrada para a categoria selecionada.</p>
        </div>
      ) : (
        Object.entries(standingsData).sort(([a], [b]) => a.localeCompare(b)).map(([category, groups]) => (
          <div key={category} className="space-y-4">
            <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b border-gray-200 pb-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
              Categoria {category}
            </h2>
            
            <div className="grid grid-cols-1 gap-6 pt-2">
              {Object.entries(groups).sort(([a], [b]) => a.localeCompare(b)).map(([groupName, teamStats]) => {
                const groupKey = `${category}-${groupName}`;
                const isExpanded = expandedGroups[groupKey] || false;
                return (
                  <div key={groupName} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <div 
                      className="bg-gray-50/80 px-6 py-3 border-b border-gray-100 flex items-center justify-between cursor-pointer hover:bg-gray-100 transition-colors"
                      onClick={() => toggleGroup(groupKey)}
                    >
                      <div className="flex items-center gap-2">
                        <Layers className="w-4 h-4 text-emerald-600" />
                        <h4 className="font-bold text-gray-700">
                          {groupName === 'Fase Única / Sem Grupo' ? groupName : `Grupo ${groupName}`}
                        </h4>
                      </div>
                      {isExpanded ? (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                    {isExpanded && (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                      <thead className="text-xs text-gray-500 uppercase bg-white border-b border-gray-100">
                        <tr>
                          <th className="px-6 py-3 font-medium w-16 text-center">Pos</th>
                          <th className="px-6 py-3 font-medium">Equipe</th>
                          <th className="px-4 py-3 font-bold text-gray-700 text-center" title="Pontos">P</th>
                          <th className="px-4 py-3 font-medium text-center" title="Jogos">J</th>
                          <th className="px-4 py-3 font-medium text-center" title="Vitórias">V</th>
                          <th className="px-4 py-3 font-medium text-center" title="Empates">E</th>
                          <th className="px-4 py-3 font-medium text-center" title="Derrotas">D</th>
                          <th className="px-4 py-3 font-medium text-center hidden sm:table-cell" title="Gols Pró">GP</th>
                          <th className="px-4 py-3 font-medium text-center hidden sm:table-cell" title="Gols Contra">GC</th>
                          <th className="px-4 py-3 font-medium text-center" title="Saldo de Gols">SG</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50">
                        {teamStats.map((team, index) => (
                          <tr
                            key={team.id}
                            className={`hover:bg-gray-50 transition-colors ${
                              index < 4 ? 'bg-emerald-50/10' : ''
                            }`}
                          >
                            <td className="px-6 py-3 text-center font-bold text-gray-900">
                              {index + 1}º
                            </td>
                            <td className="px-6 py-3">
                              <div className="flex items-center gap-3">
                                {team.logoUrl ? (
                                  <img src={team.logoUrl} alt={team.name} className="w-8 h-8 rounded-full object-cover border border-gray-200 shadow-sm" />
                                ) : (
                                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center border border-gray-200 shadow-sm">
                                    <Users className="w-4 h-4 text-gray-400" />
                                  </div>
                                )}
                                <span className="font-bold text-gray-900 whitespace-nowrap">{team.name}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-center font-bold text-emerald-700 bg-emerald-50/30">
                              {team.points}
                            </td>
                            <td className="px-4 py-3 text-center text-gray-600 font-medium">{team.played}</td>
                            <td className="px-4 py-3 text-center text-gray-600">{team.won}</td>
                            <td className="px-4 py-3 text-center text-gray-600">{team.drawn}</td>
                            <td className="px-4 py-3 text-center text-gray-600">{team.lost}</td>
                            <td className="px-4 py-3 text-center text-gray-600 hidden sm:table-cell">{team.goalsFor}</td>
                            <td className="px-4 py-3 text-center text-gray-600 hidden sm:table-cell">{team.goalsAgainst}</td>
                            <td className={`px-4 py-3 text-center font-bold ${
                              team.goalDifference > 0 ? 'text-emerald-600' : team.goalDifference < 0 ? 'text-red-600' : 'text-gray-600'
                            }`}>
                              {team.goalDifference > 0 ? `+${team.goalDifference}` : team.goalDifference}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  )}
                </div>
              );
              })}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
