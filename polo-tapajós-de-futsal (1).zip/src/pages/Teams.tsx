import React, { useState, useRef, useMemo } from 'react';
import { useStore, Category } from '../store';
import { Plus, Trash2, Users, UserPlus, Upload, Filter, Image as ImageIcon, Edit3, Save, Layers, X } from 'lucide-react';
import * as XLSX from 'xlsx';
import Cropper from 'react-easy-crop';
import getCroppedImg from '../lib/cropImage';

const CATEGORIES: Category[] = ['Sub 07', 'Sub 08', 'Sub 09', 'Sub 10', 'Sub 11', 'Sub 12', 'Sub 13', 'Sub 14', 'Sub 15', 'Sub 16', 'Sub 17', 'Sub 18', 'Sub 19', 'Sub 20'];

export default function Teams() {
  const { teams, addTeam, removeTeam, addPlayer, removePlayer, updateTeamLogo, updatePlayerStats } = useStore();
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamCategory, setNewTeamCategory] = useState<Category>('Sub 07');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<Category | 'Todas'>('Todas');
  const [selectedTeam, setSelectedTeam] = useState<string | null>(null);
  const [teamToDelete, setTeamToDelete] = useState<string | null>(null);
  const [importMessage, setImportMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);
  const [newPlayerName, setNewPlayerName] = useState('');
  const [newPlayerNumber, setNewPlayerNumber] = useState('');
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [groupModalCategory, setGroupModalCategory] = useState<Category>('Sub 07');
  const [cropImageSrc, setCropImageSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleAddTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim()) return;
    addTeam({ name: newTeamName, category: newTeamCategory });
    setNewTeamName('');
  };

  const filteredTeams = useMemo(() => {
    if (selectedCategoryFilter === 'Todas') return teams;
    return teams.filter(t => t.category === selectedCategoryFilter);
  }, [teams, selectedCategoryFilter]);

  const handleAddPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTeam || !newPlayerName.trim() || !newPlayerNumber) return;
    addPlayer(selectedTeam, {
      name: newPlayerName,
      number: parseInt(newPlayerNumber, 10),
    });
    setNewPlayerName('');
    setNewPlayerNumber('');
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedTeam) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);
        
        let importedCount = 0;
        data.forEach((row: any) => {
          // Try to find name and number columns flexibly
          const nameKey = Object.keys(row).find(k => k.toLowerCase().includes('nome') || k.toLowerCase().includes('atleta') || k.toLowerCase().includes('jogador'));
          const numberKey = Object.keys(row).find(k => k.toLowerCase().includes('num') || k.toLowerCase().includes('nº') || k.toLowerCase().includes('n°') || k.toLowerCase() === 'n');
          
          const name = nameKey ? row[nameKey] : Object.values(row)[0]; 
          const number = numberKey ? parseInt(String(row[numberKey]), 10) : parseInt(String(Object.values(row)[1] || 0), 10);
          
          if (name) {
            addPlayer(selectedTeam, {
              name: String(name),
              number: isNaN(number) ? 0 : number,
            });
            importedCount++;
          }
        });
        
        setImportMessage({ type: 'success', text: `${importedCount} atletas importados com sucesso!` });
        setTimeout(() => setImportMessage(null), 3000);
      } catch (error) {
        console.error(error);
        setImportMessage({ type: 'error', text: 'Erro ao importar planilha. Verifique o formato do arquivo.' });
        setTimeout(() => setImportMessage(null), 3000);
      }
      
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedTeam) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      if (evt.target?.result) {
        setCropImageSrc(evt.target.result as string);
      }
    };
    reader.readAsDataURL(file);
    
    if (logoInputRef.current) {
      logoInputRef.current.value = '';
    }
  };

  const onCropComplete = (croppedArea: any, croppedAreaPixels: any) => {
    setCroppedAreaPixels(croppedAreaPixels);
  };

  const handleCropSave = async () => {
    if (!cropImageSrc || !selectedTeam || !croppedAreaPixels) return;
    try {
      const croppedImage = await getCroppedImg(cropImageSrc, croppedAreaPixels);
      updateTeamLogo(selectedTeam, croppedImage);
      setCropImageSrc(null);
    } catch (e) {
      console.error(e);
    }
  };

  const handleShuffleGroups = () => {
    const numGroupsStr = window.prompt(`Em quantos grupos você deseja distribuir os times da categoria ${groupModalCategory}? (ex: 2, 4)`);
    if (!numGroupsStr) return;
    const numGroups = parseInt(numGroupsStr, 10);
    if (isNaN(numGroups) || numGroups <= 0) {
      alert("Por favor, insira um número válido maior que zero.");
      return;
    }
    useStore.getState().shuffleGroups(groupModalCategory, numGroups);
  };

  return (
    <div className="space-y-6">
      {/* Modals & Toasts */}
      {showGroupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/80 p-4">
          <div className="bg-white rounded-xl shadow-lg max-w-2xl w-full p-6 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-600" />
                Gerenciar Grupos por Categoria
              </h3>
              <button onClick={() => setShowGroupModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Selecione a Categoria</label>
              <select 
                value={groupModalCategory} 
                onChange={(e) => setGroupModalCategory(e.target.value as Category)} 
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div className="flex-1 overflow-y-auto pr-2 space-y-2 border border-gray-100 rounded-lg p-3 bg-gray-50">
              {teams.filter(t => t.category === groupModalCategory).map(team => (
                 <div key={team.id} className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg shadow-sm">
                    <span className="font-medium text-gray-900">{team.name}</span>
                    <select
                       value={team.group || ''}
                       onChange={(e) => useStore.getState().updateTeamGroup(team.id, e.target.value || undefined)}
                       className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
                    >
                       <option value="">Sem Grupo</option>
                       {CATEGORIES.map(g => (
                          <option key={g} value={g}>Grupo {g}</option>
                       ))}
                    </select>
                 </div>
              ))}
              {teams.filter(t => t.category === groupModalCategory).length === 0 && (
                 <p className="text-center text-gray-500 py-8">Nenhuma equipe cadastrada nesta categoria.</p>
              )}
            </div>
            
            <div className="mt-6 flex justify-between items-center">
               <button 
                 onClick={handleShuffleGroups} 
                 className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors text-sm"
               >
                 Sortear Grupos
               </button>
               <button onClick={() => setShowGroupModal(false)} className="px-5 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors">
                 Concluído
               </button>
            </div>
          </div>
        </div>
      )}

      {cropImageSrc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/80 p-4">
          <div className="bg-white rounded-xl shadow-lg max-w-lg w-full p-6 flex flex-col h-[80vh]">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Ajustar Escudo</h3>
            <div className="relative flex-1 bg-gray-100 rounded-lg overflow-hidden mb-6">
              <Cropper
                image={cropImageSrc}
                crop={crop}
                zoom={zoom}
                aspect={1}
                onCropChange={setCrop}
                onCropComplete={onCropComplete}
                onZoomChange={setZoom}
                cropShape="round"
                showGrid={false}
              />
            </div>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Zoom</label>
              <input
                type="range"
                value={zoom}
                min={1}
                max={3}
                step={0.1}
                aria-labelledby="Zoom"
                onChange={(e) => setZoom(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setCropImageSrc(null)} className="px-4 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg transition-colors">Cancelar</button>
              <button 
                onClick={handleCropSave} 
                className="px-4 py-2 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors"
              >
                Salvar Escudo
              </button>
            </div>
          </div>
        </div>
      )}

      {teamToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50 p-4">
          <div className="bg-white rounded-xl shadow-lg max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Excluir Equipe</h3>
            <p className="text-gray-500 mb-6">Tem certeza que deseja excluir esta equipe? Todas as partidas relacionadas também serão removidas. Esta ação não pode ser desfeita.</p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setTeamToDelete(null)} className="px-4 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg transition-colors">Cancelar</button>
              <button 
                onClick={() => {
                  removeTeam(teamToDelete);
                  if (selectedTeam === teamToDelete) setSelectedTeam(null);
                  setTeamToDelete(null);
                }} 
                className="px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {importMessage && (
        <div className={`fixed bottom-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg font-medium text-white ${importMessage.type === 'success' ? 'bg-emerald-600' : 'bg-red-600'}`}>
          {importMessage.text}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Equipes</h1>
          <p className="text-gray-500 mt-1">Gerencie as equipes e elencos do campeonato.</p>
        </div>
        <button
          onClick={() => setIsAdminMode(!isAdminMode)}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            isAdminMode 
              ? 'bg-emerald-600 text-white hover:bg-emerald-700' 
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          {isAdminMode ? (
            <>
              <Save className="w-5 h-5" />
              Salvar Alterações
            </>
          ) : (
            <>
              <Edit3 className="w-5 h-5" />
              Editar Estatísticas
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Teams List */}
        <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Adicionar Equipe</h2>
          <form onSubmit={handleAddTeam} className="flex flex-col gap-2 mb-6">
            <input
              type="text"
              placeholder="Nome da equipe"
              value={newTeamName}
              onChange={(e) => setNewTeamName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
            />
            <div className="flex gap-2">
              <select
                value={newTeamCategory}
                onChange={(e) => setNewTeamCategory(e.target.value as Category)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              <button
                type="submit"
                className="p-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
          </form>

          <div className="flex items-center gap-2 mb-4 pb-4 border-b border-gray-100">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={selectedCategoryFilter}
              onChange={(e) => {
                setSelectedCategoryFilter(e.target.value as Category | 'Todas');
                setSelectedTeam(null);
              }}
              className="flex-1 text-sm border-none bg-transparent focus:ring-0 text-gray-600 font-medium cursor-pointer"
            >
              <option value="Todas">Todas as Categorias</option>
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            <button
              onClick={() => {
                setGroupModalCategory(selectedCategoryFilter === 'Todas' ? 'Sub 07' : selectedCategoryFilter);
                setShowGroupModal(true);
              }}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
            >
              <Layers className="w-3.5 h-3.5" />
              Grupos
            </button>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
            {filteredTeams.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-4">Nenhuma equipe encontrada.</p>
            ) : (
              filteredTeams.map((team) => (
                <div
                  key={team.id}
                  className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedTeam === team.id
                      ? 'border-emerald-500 bg-emerald-50'
                      : 'border-gray-200 hover:border-emerald-300'
                  }`}
                  onClick={() => setSelectedTeam(team.id)}
                >
                  <div className="flex items-center gap-3">
                    {team.logoUrl ? (
                      <img src={team.logoUrl} alt={team.name} className="w-10 h-10 rounded-full object-cover border border-gray-200" />
                    ) : (
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-500 border border-gray-200">
                        <Users className="w-5 h-5" />
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-gray-900">{team.name}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded text-[10px] font-bold uppercase tracking-wider">
                          {team.category}
                        </span>
                        {team.group && (
                          <span className="px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded text-[10px] font-bold uppercase tracking-wider">
                            Grupo {team.group}
                          </span>
                        )}
                        <p className="text-xs text-gray-500">{team.players.length} atletas</p>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setTeamToDelete(team.id);
                    }}
                    className="p-1.5 text-gray-400 hover:text-red-600 rounded-md hover:bg-red-50 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Team Details / Roster */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          {selectedTeam ? (
            <>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div 
                    className="w-16 h-16 shrink-0 rounded-full bg-gray-50 border-2 border-dashed border-gray-300 flex items-center justify-center cursor-pointer overflow-hidden relative group hover:border-emerald-500 transition-colors"
                    onClick={() => logoInputRef.current?.click()}
                    title="Alterar escudo da equipe"
                  >
                    {teams.find((t) => t.id === selectedTeam)?.logoUrl ? (
                      <>
                        <img 
                          src={teams.find((t) => t.id === selectedTeam)?.logoUrl} 
                          alt="Escudo" 
                          className="w-full h-full object-contain p-1 bg-white"
                        />
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <ImageIcon className="w-6 h-6 text-white" />
                        </div>
                      </>
                    ) : (
                      <div className="text-gray-400 flex flex-col items-center group-hover:text-emerald-500 transition-colors">
                        <ImageIcon className="w-6 h-6" />
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    ref={logoInputRef}
                    onChange={handleLogoUpload}
                  />
                  <div>
                    <h2 className="text-xl font-bold text-gray-900">
                      {teams.find((t) => t.id === selectedTeam)?.name}
                    </h2>
                    <span className="inline-block mt-1 px-2 py-1 bg-emerald-100 text-emerald-800 rounded text-xs font-bold uppercase tracking-wider">
                      {teams.find((t) => t.id === selectedTeam)?.category}
                    </span>
                  </div>
                </div>
                <div>
                  <input
                    type="file"
                    accept=".xlsx, .xls"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleImport}
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-emerald-700 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors"
                  >
                    <Upload className="w-4 h-4" />
                    Importar Planilha
                  </button>
                </div>
              </div>

              <form onSubmit={handleAddPlayer} className="grid grid-cols-12 gap-2 mb-6">
                <div className="col-span-8">
                  <input
                    type="text"
                    placeholder="Nome do atleta"
                    value={newPlayerName}
                    onChange={(e) => setNewPlayerName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                  />
                </div>
                <div className="col-span-3">
                  <input
                    type="number"
                    placeholder="Nº"
                    value={newPlayerNumber}
                    onChange={(e) => setNewPlayerNumber(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                  />
                </div>
                <div className="col-span-1">
                  <button
                    type="submit"
                    className="w-full h-full flex items-center justify-center bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                  >
                    <UserPlus className="w-5 h-5" />
                  </button>
                </div>
              </form>

              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-4 py-3 font-medium">Nº</th>
                      <th className="px-4 py-3 font-medium">Nome</th>
                      <th className="px-4 py-3 font-medium text-center">Gols</th>
                      <th className="px-4 py-3 font-medium text-center">CA</th>
                      <th className="px-4 py-3 font-medium text-center">CV</th>
                      <th className="px-4 py-3 font-medium text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teams.find((t) => t.id === selectedTeam)?.players.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                          Nenhum atleta cadastrado neste elenco.
                        </td>
                      </tr>
                    ) : (
                      teams
                        .find((t) => t.id === selectedTeam)
                        ?.players.map((player, index) => (
                          <tr key={player.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                            <td className="px-4 py-3 font-medium text-gray-900">
                              {(index + 1).toString().padStart(2, '0')}
                            </td>
                            <td className={`px-4 py-3 ${(player.yellowCards >= 3 || player.redCards >= 1) ? 'text-red-600 font-bold' : ''}`}>
                              {player.name} {player.number ? `(#${player.number})` : ''}
                            </td>
                            <td className="px-4 py-3 text-center">
                              <input
                                type="number"
                                min="0"
                                max="10"
                                value={player.goals}
                                onChange={(e) => {
                                  let val = parseInt(e.target.value) || 0;
                                  if (val > 10) val = 10;
                                  if (val < 0) val = 0;
                                  updatePlayerStats(selectedTeam, player.id, { goals: val });
                                }}
                                className="w-14 text-center border border-gray-300 rounded px-1 py-0.5 focus:ring-1 focus:ring-emerald-500 outline-none bg-white"
                              />
                            </td>
                            <td className="px-4 py-3 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <span className="inline-block w-4 h-6 bg-yellow-400 rounded-sm"></span>
                                <input
                                  type="number"
                                  min="0"
                                  max="3"
                                  value={player.yellowCards}
                                  onChange={(e) => {
                                    let val = parseInt(e.target.value) || 0;
                                    if (val > 3) val = 3;
                                    if (val < 0) val = 0;
                                    updatePlayerStats(selectedTeam, player.id, { yellowCards: val });
                                  }}
                                  className="w-14 text-center border border-gray-300 rounded px-1 py-0.5 focus:ring-1 focus:ring-emerald-500 outline-none bg-white"
                                />
                              </div>
                            </td>
                            <td className="px-4 py-3 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <span className="inline-block w-4 h-6 bg-red-500 rounded-sm"></span>
                                <input
                                  type="number"
                                  min="0"
                                  max="2"
                                  value={player.redCards}
                                  onChange={(e) => {
                                    let val = parseInt(e.target.value) || 0;
                                    if (val > 2) val = 2;
                                    if (val < 0) val = 0;
                                    updatePlayerStats(selectedTeam, player.id, { redCards: val });
                                  }}
                                  className="w-14 text-center border border-gray-300 rounded px-1 py-0.5 focus:ring-1 focus:ring-emerald-500 outline-none bg-white"
                                />
                              </div>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <button
                                onClick={() => removePlayer(selectedTeam, player.id)}
                                className="text-gray-400 hover:text-red-600 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))
                    )}
                  </tbody>
                </table>
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-gray-500 py-12">
              <Users className="w-12 h-12 text-gray-300 mb-4" />
              <p>Selecione uma equipe para gerenciar seu elenco.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
