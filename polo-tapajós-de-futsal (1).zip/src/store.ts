import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Player {
  id: string;
  name: string;
  number: number;
  goals: number;
  yellowCards: number;
  redCards: number;
}

export type Category = 'Sub 07' | 'Sub 08' | 'Sub 09' | 'Sub 10' | 'Sub 11' | 'Sub 12' | 'Sub 13' | 'Sub 14' | 'Sub 15' | 'Sub 16' | 'Sub 17' | 'Sub 18' | 'Sub 19' | 'Sub 20';

export interface Team {
  id: string;
  name: string;
  category: Category;
  group?: string;
  logoUrl?: string;
  players: Player[];
}

export interface MatchEvent {
  id: string;
  type: 'goal' | 'yellow_card' | 'red_card';
  playerId: string;
  teamId: string;
  minute?: number;
}

export interface Match {
  id: string;
  homeTeamId: string;
  awayTeamId: string;
  date: string;
  status: 'scheduled' | 'in_progress' | 'finished';
  homeScore: number;
  awayScore: number;
  events: MatchEvent[];
}

interface TournamentState {
  name: string;
  teams: Team[];
  matches: Match[];
  setName: (name: string) => void;
  addTeam: (team: Omit<Team, 'id' | 'players'>) => void;
  removeTeam: (id: string) => void;
  addPlayer: (teamId: string, player: Omit<Player, 'id' | 'goals' | 'yellowCards' | 'redCards'>) => void;
  removePlayer: (teamId: string, playerId: string) => void;
  updatePlayerStats: (teamId: string, playerId: string, stats: Partial<Pick<Player, 'goals' | 'yellowCards' | 'redCards'>>) => void;
  addMatch: (match: Omit<Match, 'id' | 'events' | 'homeScore' | 'awayScore' | 'status'>) => void;
  removeMatch: (id: string) => void;
  updateMatchScore: (matchId: string, homeScore: number, awayScore: number) => void;
  updateMatchStatus: (matchId: string, status: Match['status']) => void;
  addMatchEvent: (matchId: string, event: Omit<MatchEvent, 'id'>) => void;
  removeMatchEvent: (matchId: string, eventId: string) => void;
  generateRoundRobin: (doubleRoundRobin?: boolean) => void;
  updateTeamLogo: (teamId: string, logoUrl: string) => void;
  updateTeamGroup: (teamId: string, group?: string) => void;
  shuffleGroups: (category: Category, numGroups: number) => void;
}

const generateId = () => Math.random().toString(36).substring(2, 9);

export const useStore = create<TournamentState>()(
  persist(
    (set) => ({
      name: 'Polo Tapajós de Futsal',
      teams: [],
      matches: [],
      setName: (name) => set({ name }),
      addTeam: (team) =>
        set((state) => ({
          teams: [...state.teams, { ...team, id: generateId(), players: [] }],
        })),
      removeTeam: (id) =>
        set((state) => ({
          teams: state.teams.filter((t) => t.id !== id),
          matches: state.matches.filter((m) => m.homeTeamId !== id && m.awayTeamId !== id),
        })),
      addPlayer: (teamId, player) =>
        set((state) => ({
          teams: state.teams.map((t) =>
            t.id === teamId
              ? {
                  ...t,
                  players: [
                    ...t.players,
                    { ...player, id: generateId(), goals: 0, yellowCards: 0, redCards: 0 },
                  ],
                }
              : t
          ),
        })),
      removePlayer: (teamId, playerId) =>
        set((state) => ({
          teams: state.teams.map((t) =>
            t.id === teamId
              ? { ...t, players: t.players.filter((p) => p.id !== playerId) }
              : t
          ),
        })),
      updatePlayerStats: (teamId, playerId, stats) =>
        set((state) => ({
          teams: state.teams.map((t) =>
            t.id === teamId
              ? {
                  ...t,
                  players: t.players.map((p) =>
                    p.id === playerId ? { ...p, ...stats } : p
                  ),
                }
              : t
          ),
        })),
      addMatch: (match) =>
        set((state) => ({
          matches: [
            ...state.matches,
            { ...match, id: generateId(), events: [], homeScore: 0, awayScore: 0, status: 'scheduled' },
          ],
        })),
      removeMatch: (id) =>
        set((state) => ({
          matches: state.matches.filter((m) => m.id !== id),
        })),
      updateMatchScore: (matchId, homeScore, awayScore) =>
        set((state) => ({
          matches: state.matches.map((m) =>
            m.id === matchId ? { ...m, homeScore, awayScore } : m
          ),
        })),
      updateMatchStatus: (matchId, status) =>
        set((state) => ({
          matches: state.matches.map((m) =>
            m.id === matchId ? { ...m, status } : m
          ),
        })),
      addMatchEvent: (matchId, event) =>
        set((state) => {
          const newEvent = { ...event, id: generateId() };
          
          // Update player stats if it's a finished match or we want to keep running stats
          // Let's keep it simple and calculate stats dynamically from events later, 
          // or update them here. For now, we just store the event.
          
          return {
            matches: state.matches.map((m) => {
              if (m.id === matchId) {
                const updatedEvents = [...m.events, newEvent];
                // Auto-update score if it's a goal
                let newHomeScore = m.homeScore;
                let newAwayScore = m.awayScore;
                if (event.type === 'goal') {
                  if (event.teamId === m.homeTeamId) newHomeScore++;
                  if (event.teamId === m.awayTeamId) newAwayScore++;
                }
                return { ...m, events: updatedEvents, homeScore: newHomeScore, awayScore: newAwayScore };
              }
              return m;
            }),
          };
        }),
      removeMatchEvent: (matchId, eventId) =>
        set((state) => ({
          matches: state.matches.map((m) => {
            if (m.id === matchId) {
              const eventToRemove = m.events.find(e => e.id === eventId);
              const updatedEvents = m.events.filter((e) => e.id !== eventId);
              
              let newHomeScore = m.homeScore;
              let newAwayScore = m.awayScore;
              if (eventToRemove?.type === 'goal') {
                if (eventToRemove.teamId === m.homeTeamId) newHomeScore--;
                if (eventToRemove.teamId === m.awayTeamId) newAwayScore--;
              }
              
              return { ...m, events: updatedEvents, homeScore: newHomeScore, awayScore: newAwayScore };
            }
            return m;
          }),
        })),
      generateRoundRobin: (doubleRoundRobin = false) =>
        set((state) => {
          const teams = state.teams;
          if (teams.length < 2) return state;

          const newMatches: Match[] = [];
          
          // Group teams by category, then by group
          const groupedTeams: Record<string, Record<string, typeof teams>> = {};
          teams.forEach(team => {
            const cat = team.category;
            const group = team.group || 'Fase Única / Sem Grupo';
            
            if (!groupedTeams[cat]) groupedTeams[cat] = {};
            if (!groupedTeams[cat][group]) groupedTeams[cat][group] = [];
            
            groupedTeams[cat][group].push(team);
          });

          // Generate round-robin for each group
          Object.values(groupedTeams).forEach(categories => {
            Object.values(categories).forEach(groupTeams => {
              if (groupTeams.length < 2) return;
              
              const teamIds = groupTeams.map(t => t.id);
              for (let i = 0; i < teamIds.length; i++) {
                for (let j = i + 1; j < teamIds.length; j++) {
                  // Sorteio de quem é o mandante na ida para não ficar repetindo
                  const isHome = Math.random() > 0.5;
                  const firstMatchHome = isHome ? teamIds[i] : teamIds[j];
                  const firstMatchAway = isHome ? teamIds[j] : teamIds[i];

                  // Home vs Away
                  newMatches.push({
                    id: generateId(),
                    homeTeamId: firstMatchHome,
                    awayTeamId: firstMatchAway,
                    date: new Date().toISOString(), // Default to now, user can edit later
                    status: 'scheduled',
                    homeScore: 0,
                    awayScore: 0,
                    events: [],
                  });

                  // Away vs Home (If double round-robin)
                  if (doubleRoundRobin) {
                    newMatches.push({
                      id: generateId(),
                      homeTeamId: firstMatchAway, // Swapped
                      awayTeamId: firstMatchHome, // Swapped
                      date: new Date().toISOString(),
                      status: 'scheduled',
                      homeScore: 0,
                      awayScore: 0,
                      events: [],
                    });
                  }
                }
              }
            });
          });

          // Shuffle the newMatches array array (Fisher-Yates)
          for (let i = newMatches.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [newMatches[i], newMatches[j]] = [newMatches[j], newMatches[i]];
          }

          return { matches: [...state.matches, ...newMatches] };
        }),
      updateTeamLogo: (teamId, logoUrl) =>
        set((state) => ({
          teams: state.teams.map((t) =>
            t.id === teamId ? { ...t, logoUrl } : t
          ),
        })),
      updateTeamGroup: (teamId, group) =>
        set((state) => ({
          teams: state.teams.map((t) =>
            t.id === teamId ? { ...t, group } : t
          ),
        })),
      shuffleGroups: (category, numGroups) => {
        set((state) => {
          const categoryTeams = state.teams.filter(t => t.category === category);
          if (categoryTeams.length === 0 || numGroups <= 0) return state;

          // Shuffle teams
          const shuffled = [...categoryTeams];
          for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
          }

          // Assign to groups A, B, C, D...
          const groupNames = Array.from({ length: numGroups }, (_, i) => String.fromCharCode(65 + i));
          
          const teamUpdates = new Map();
          shuffled.forEach((team, index) => {
            const groupIndex = index % numGroups;
            teamUpdates.set(team.id, groupNames[groupIndex]);
          });

          return {
            teams: state.teams.map(t => 
              teamUpdates.has(t.id) ? { ...t, group: teamUpdates.get(t.id) } : t
            )
          };
        });
      },
    }),
    {
      name: 'polo-tapajos-storage',
    }
  )
);
